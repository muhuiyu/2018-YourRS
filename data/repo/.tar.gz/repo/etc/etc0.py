if self.bname == '80': self.bname = '080'
if self.bname == 'babaria 西班牙babaria': self.bname = '西班牙Babaria'

if self.pid == '2761':  self.pname = '水感透顏粉底精華spf30pa'
if self.pid == '7750':  self.pname = '巴黎時尚伸展台高級訂製濃翹美睫膏'
if self.pid == '11449': self.pname = '魚子高效活氧亮白精華液'
if self.pid == '12502': self.pname = '無瑕娃娃粉餅spf18pa'
if self.pid == '12877': self.pname = '愛麗絲完美勾勒眼線膠筆'
if self.pid == '13315': self.pname = '保濕修復膠囊面膜a'
if self.pid == '13324': self.pname = '保濕舒緩膠囊面膜b'
if self.pid == '13336': self.pname = '緊緻抗皺膠囊面膜e'
if self.pid == '13342': self.pname = '再生煥膚膠囊面膜d'
if self.pid == '13345': self.pname = '瞬效亮白膠囊面膜c'

# 瑰珀翠 巴黎夢幻花戀
if self.pid == '3544' : self.pname += '香水'

# 倩碧 蜜糖啾啾馬卡龍
if self.pid == '8359':  self.pname += '護唇膏'

# diptyque 多米諾堤之水
if self.pid == '16489': self.pname += '香水'

# jomalonelondon
if self.pid == '5554' : self.pname += '香水'
if self.pid == '5557' : self.pname += '香水'
if self.pid == '5560' : self.pname += '香水'
if self.pid == '6085' : self.pname += '香水'
if self.pid == '7918' : self.pname += '香水'
if self.pid == '7921' : self.pname += '香水'
if self.pid == '8203' : self.pname += '香水'
if self.pid == '16834': self.pname += '香水'
if self.pid == '18097': self.pname += '香水'
if self.pid == '18100': self.pname += '香水'
if self.pid == '18103': self.pname += '香水'
if self.pid == '18106': self.pname += '香水'
if self.pid == '18109': self.pname += '香水'
if self.pid == '18157': self.pname += '香水'
if self.pid == '18160': self.pname += '香水'
if self.pid == '18163': self.pname += '香水'
if self.pid == '18166': self.pname += '香水'
if self.pid == '18169': self.pname += '香水'
if self.pid == '18172': self.pname += '香水'
